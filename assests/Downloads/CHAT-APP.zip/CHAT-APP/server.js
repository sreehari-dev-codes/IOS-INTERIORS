const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // When a user joins a room
    socket.on('join room', (room) => {
        socket.join(room);
        console.log(`User ${socket.id} joined room ${room}`);
        socket.to(room).emit('message', `User ${socket.id} has joined the room.`);
    });

    // Handle chat messages in rooms
    socket.on('chat message', (data) => {
        const { room, message } = data;
        io.to(room).emit('chat message', message);
    });

    // Handle private messages
    socket.on('private message', (data) => {
        const { recipientId, message } = data;
        socket.to(recipientId).emit('private message', { message, senderId: socket.id });
    });

    socket.on('disconnect', () => {
        console.log(`User ${socket.id} disconnected`);
    });
});

server.listen(8082, () => {
    console.log('Server is running on port 8082');
});
