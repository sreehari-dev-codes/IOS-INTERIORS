exports.register = (req,res)=>{
    res.render("register")
}
exports.login = (req,res)=>{
    res.render("login")
}
exports.chat = (req,res)=>{
    res.render("chat")
}
exports.userChat = (req,res)=>{
    res.render("userChat")
}
