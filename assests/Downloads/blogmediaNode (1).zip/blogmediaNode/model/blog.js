
const mongoose=require("mongoose")


const blogSchema= new mongoose.Schema({

    title:{
        type:String,
        required:true
    },

    content:{
        type:String,
        required:true,
    },

    creatingUser:{
        type: mongoose.Schema.Types.ObjectId,
        ref:"user", // connectin user vlog id
        required:true

    }
})


const blog= mongoose.model("Blog",blogSchema)

module.exports= blog