const express=require("express");
const routing= express.Router();
const {handlesignUpuser,handleLoginUser}=require("../Controller/user");
const path=require("path");
const cookieParser = require("cookie-parser");
const {validateToken}=require("../Middleware/auth")

 routing.use(cookieParser())
routing.post("/signupUser",handlesignUpuser)

routing.get('/',(req,res)=>{
    res.render(path.join(__dirname,"../view/signup.ejs"))
})
// routing.get("/home",validateToken,(req,res)=>{

//     res.render(path.join(__dirname,'../view/home.ejs'),{
//         logged:true,
//         userName:res.locals.userName
//     })
// })

routing.get("/login",(req,res)=>{
    res.render(path.join(__dirname,"../view/login.ejs"),{
        // logged:true,
        // userName:res.locals.userName
    })
 
})


routing.post("/loginUser",handleLoginUser)


module.exports=routing













