const express=require("express");
const path = require("path");
const routing= express.Router();
const {validateToken}=require("../Middleware/auth")
const {handleUserCreatePost,handleFetchingBlogs,userProfile,handleBlogDelete, handleBlogEditDisplay,editBlog,handlerLogOut}=require("../Controller/blog")


routing.get("/blogForm",validateToken,(req,res)=>{  
    res.render(path.join(__dirname,"../view/create.ejs"))
})

routing.get("/home",validateToken, handleFetchingBlogs)

routing.post('/createBlog',validateToken,handleUserCreatePost)

routing.get("/profile",validateToken,userProfile)

routing.get("/deleteBlog/:id",validateToken,handleBlogDelete)

routing.get("/editblog/:id",validateToken,handleBlogEditDisplay)
routing.post("/editblog/:id",validateToken,editBlog)
routing.get("/logOut",validateToken,handlerLogOut)

// routing.get("/editBlog/:id", validateToken, async (req,res)=>{
//     res.render(path.join(__dirname,"../view/edit.ejs"))
// })

//  routing.route("/userBlog/:id")
//  .get(async(req,res)=>{
//     const userDetails= req.params.id
//     console.log(userDetails,"_id");
//  })
// .delete(validateToken, handleBlogDelete)
module.exports=routing

