const Blog=require("../model/blog")
const User=require("../model/user")
const path=require("path")


async  function handleUserCreatePost(req,res){

  
   
    // get all data From body
    const {title,content}=req.body

    if(!(title&&content)){
  
     return   res.status(400).send({error:" title and content are  required "})
    }

   try{
    const  CreatePost= await Blog.create({

      title,
      content,
      creatingUser:req.user.id    
     });
  
     console.log("creatingPost",CreatePost);
     return res.status(200).send({succuss:"succussFully added"},res.redirect("/home"))
   }catch(error){
    console.error("error creating post:",error);
    return res.status(500).send({ error: "Internal Server Error" });
    
   }
}



async function handleFetchingBlogs(req,res){

  try{
    const blog=  await Blog.find();
  
    res.render(path.join(__dirname,"../view/home.ejs"),{blog}); 
  }catch(err){

    res.status(500).json({error:"fetchig data error"})
  }
}


async function userProfile(req,res){

  const userId=req.user.id
  console.log(userId);


    const blogs= await Blog.find({ creatingUser:userId})
    // console.log(blogs);
  
  res.render(path.join(__dirname,"../view/profile.ejs"),{blogs})

}

async function handleBlogDelete(req,res){

   const blogId= await req.params.id
  
   const blog= await Blog.findOne({_id:blogId});
   console.log(blog);

    const deleteing=  await Blog.findByIdAndDelete(blogId)
    console.log(deleteing,"succuufully");

    res.redirect("/profile")
}


async function handleBlogEditDisplay(req,res){
   
  const blogId= await req.params.id
  console.log(blogId,"editId Recived");

  const editBlog= await Blog.findById(blogId)
  console.log(editBlog);

  if(editBlog){
    res.render(path.join(__dirname,"../view/edit.ejs"),{editBlog})
  }
  res.red
   
}



async function editBlog(req,res){

  // const  blogId=req.params.id
  const {title,content}=req.body;

  
  const updateBlog= await Blog.findByIdAndUpdate(req.params.id,{title,content},{new:true})
  console.log(updateBlog,"updated Vlogs");

 

  if(updateBlog){
    res.redirect("/profile")
  }
 
    
}


async function handlerLogOut(req,res){
  
   try{

      // jwt token clear cookies
  res.clearCookie("token");
  
  return res.redirect("/")
   }catch(err){
     
    console.log(err,"err in logOut ");
    return res.status(500).json({msg:"error in logout"})

   }
  

  
}
  


module.exports={

    handleUserCreatePost,
    handleFetchingBlogs,
    userProfile,
    handleBlogDelete,
    handleBlogEditDisplay ,
    editBlog,
    handlerLogOut
}



