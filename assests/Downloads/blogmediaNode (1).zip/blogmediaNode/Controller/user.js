
const User=require('../model/user')
const bcrypt=require("bcryptjs")
const path=require("path")
const jwt=require("jsonwebtoken")
const cookiesparser=require("cookie-parser")





   // userSignUp

  async function handlesignUpuser(req,res){

    // get all Data from body:
    const {userName,email,password}=req.body
    // all the data should exists
    if(!(userName&&email&&password)){
     res.status(400).send({msg:"not all feilds required"})
    }
    // check if user already exists
    const existsUser= await User.findOne({email})

    if(existsUser){
     return  res.status(401).send({ msg: "this email already loged"})
    }

    // password bycript

    const hashPassword= await bcrypt.hash(password,8)
  
    // save the user database
    const  newUser= await User.create({
        userName,
        email,
        password:hashPassword
    })
   
    console.log('newUserDetails',newUser);
    return  res.status(200).render(path.join(__dirname,"../view/login.ejs"))

}

  async function handleLoginUser(req,res){

   try{
     // get all data from body
     const {email,password}=req.body;
     // all the data should exists
     if(!(email&&password)){
         res.status(400).send({msg:"not all feild required"})
     }
 
     // check all email exixts 
      const user=await User.findOne({email})
 
        if(user&& await bcrypt.compare(password,user.password)){
 
         const token=jwt.sign(
             {id:user.id,userName:user.userName},
              'sdddd',
              {
                 expiresIn:'2h'
              }
         )
         const option={
             expires:new Date(Date.now()+3*24*60*60*1000),
             httpOnly:true
         };
 
 
           res.cookie("token",token,option)
 
           return res.redirect("/home")
 
        }else{
 
         res.status(401).render(path.join(__dirname,"../view/login.ejs"))
          throw new Error("invalid email or password")
        }
   }catch(err){
    console.log(err,"network error");
   }
  }





 

module.exports={
   
    handlesignUpuser,handleLoginUser

}
