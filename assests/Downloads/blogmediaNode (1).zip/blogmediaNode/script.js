const express=require("express")
const port=process.env.port||8000;
const app=express()
const {connectMongoDB}=require("./connection.js")
const routingUser=require("./Routing/user")
const path=require("path")
const routingBlogs = require("./Routing/blog")

   

// middleware use

app.use(express.urlencoded({extended:true}))
app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname,"public")))

// connectingMongoDb
connectMongoDB("mongodb://127.0.0.1:27017/blogApp")
.then(()=>{
    console.log("connected MongoDB");
})   
   
 
app.use('/',routingUser)
app.use("/",routingBlogs)
      
  
 
app.listen(port,()=>{
    console.log(`server running on`+port);
    
})    