
const jwt =require("jsonwebtoken")
// const cookieParser=require("cookie-parser");
const path = require("path");

async function validateToken(req,res,next){

    //get token from cookies
    const token= req.cookies.token
    console.log(token,"validatingToken");
    // checking token validation
    if(!token){
        res.status(401).send({msg:"not  valid token"})
    }
 

    try{
        const verified=jwt.verify(token,"sdddd");
        req.user=verified;
        res.locals.userName=verified.userName
        next();
    }catch(err){
        console.log(err,"network error");
        return res.render(path.join(__dirname,"../view/signup.ejs"),{error:"invalid token"})
    }
}


module.exports={
    validateToken
}